import { isOverdue } from './dates'

export function countByStatus(tasks) {
  return {
    pending: tasks.filter((t) => t.status === 'pending').length,
    completed: tasks.filter((t) => t.status === 'completed').length,
    needs_review: tasks.filter((t) => t.status === 'needs_review').length,
    overdue: tasks.filter(isOverdue).length,
  }
}

// Follow-up progress = share of tasks completed (0–100)
export function progressPercent(tasks) {
  if (!tasks.length) return 0
  return Math.round((tasks.filter((t) => t.status === 'completed').length / tasks.length) * 100)
}
