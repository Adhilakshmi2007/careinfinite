// Small date helpers. Mock data uses "days from today" so the demo never looks stale.

export function daysFromNow(n) {
  const d = new Date()
  d.setHours(9, 0, 0, 0)
  d.setDate(d.getDate() + n)
  return d.toISOString()
}

export function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

// "Due today", "Due in 3 days", "2 days overdue"
export function dueLabel(iso) {
  const ms = new Date(iso).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0)
  const days = Math.round(ms / 86400000)
  if (days === 0) return 'Due today'
  if (days === 1) return 'Due tomorrow'
  if (days > 1) return `Due in ${days} days`
  if (days === -1) return '1 day overdue'
  return `${Math.abs(days)} days overdue`
}

export function isOverdue(task) {
  if (task.status !== 'pending') return false
  return new Date(task.due).setHours(0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0)
}
