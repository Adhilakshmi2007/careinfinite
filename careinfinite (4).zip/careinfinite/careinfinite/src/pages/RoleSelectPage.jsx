import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import { ROLES, useRole } from '../context/RoleContext'

const DESCRIPTIONS = {
  patient: 'See your tasks, timeline, reminders and warning signs in simple language.',
  staff: 'Track follow-up progress across patients and upload discharge summaries.',
  reviewer: 'Check items the AI was unsure about and resolve them against the source.',
}

export default function RoleSelectPage() {
  const { setRole } = useRole()
  const navigate = useNavigate()

  function choose(key) {
    setRole(key)
    navigate('/auth')
  }

  return (
    <div className="container-page py-12">
      <PageHeader title="Who is using CareInfinite?" subtitle="Pick a role to sign in." />
      <div className="mt-8 grid gap-5 md:grid-cols-3">
        {Object.entries(ROLES).map(([key, r]) => (
          <button key={key} onClick={() => choose(key)} className="card p-6 text-left transition-colors hover:border-tide-500 hover:bg-mist-50">
            <h2 className="text-2xl">{r.label}</h2>
            <p className="mt-2 text-sm text-ink-soft">{DESCRIPTIONS[key]}</p>
            <span className="mt-5 inline-block text-sm font-semibold text-tide-700">Sign in as {r.label.toLowerCase()}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
