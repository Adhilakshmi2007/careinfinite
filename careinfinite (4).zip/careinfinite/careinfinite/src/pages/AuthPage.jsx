import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ROLES, useRole } from '../context/RoleContext'

export default function AuthPage() {
  const { role } = useRole()
  const navigate = useNavigate()
  
  // Generic fields
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  
  // Staff specific fields
  const [hospitalName, setHospitalName] = useState('')
  const [staffId, setStaffId] = useState('')
  const [email, setEmail] = useState('')
  const [jobRole, setJobRole] = useState('') // "Role" within staff like Doctor, Nurse
  
  const [isLogin, setIsLogin] = useState(true)
  const [error, setError] = useState('')

  // If someone lands here without a role, send them back
  if (!role) {
    navigate('/roles')
    return null
  }

  const roleLabel = ROLES[role]?.label || 'User'
  const isStaff = role === 'staff'

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    
    if (isLogin) {
      // Handle Sign In
      try {
        const response = await fetch('http://localhost:5000/api/auth/signin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            identifier: name, // User types name or email here
            password: password,
            role: role
          })
        });

        const data = await response.json();

        if (!response.ok) {
          setError(data.error || 'Failed to sign in.');
          return;
        }

        // Store user in local state or localStorage if needed for session
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        navigate(ROLES[role].path);
      } catch (err) {
        setError('Server is unreachable. Make sure the backend is running.');
      }
    } else {
      // Handle Sign Up
      if (password !== confirmPassword) {
        setError('Passwords do not match.')
        return
      }

      try {
        const payload = {
          role: role,
          name: name,
          password: password,
          ...(isStaff && { hospitalName, staffId, email, jobRole })
        };

        const response = await fetch('http://localhost:5000/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
          setError(data.error || 'Failed to sign up.');
          return;
        }

        // Success
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        navigate(ROLES[role].path);
      } catch (err) {
        setError('Server is unreachable. Make sure the backend is running.');
      }
    }
  }

  return (
    <div className="container-page py-12 max-w-md mx-auto">
      <div className="card p-8">
        <h2 className="text-2xl font-semibold mb-6">
          {isLogin ? 'Sign In' : 'Sign Up'} as {roleLabel}
        </h2>
        
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          
          {/* Sign in always just asks for Name/Identifier and Password */}
          {isLogin ? (
            <>
              <div>
                <label className="block text-sm font-medium text-ink mb-1">
                  {isStaff ? 'Email or Full Name' : 'Name'}
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                  placeholder={isStaff ? 'Enter your email or name' : `Enter your ${roleLabel.toLowerCase()} name`}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-ink mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                  placeholder="Enter password"
                />
              </div>
            </>
          ) : (
            /* Sign Up Fields */
            <>
              <div>
                <label className="block text-sm font-medium text-ink mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                  placeholder="Enter your full name"
                />
              </div>

              {isStaff && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-ink mb-1">
                      Hospital Name
                    </label>
                    <input
                      type="text"
                      required
                      value={hospitalName}
                      onChange={(e) => setHospitalName(e.target.value)}
                      className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                      placeholder="e.g. General Hospital"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-ink mb-1">
                      Staff ID
                    </label>
                    <input
                      type="text"
                      required
                      value={staffId}
                      onChange={(e) => setStaffId(e.target.value)}
                      className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                      placeholder="e.g. EMP-12345"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-ink mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                      placeholder="doctor@hospital.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-ink mb-1">
                      Role
                    </label>
                    <input
                      type="text"
                      required
                      value={jobRole}
                      onChange={(e) => setJobRole(e.target.value)}
                      className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                      placeholder="e.g. Nurse, Doctor, Administrator"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium text-ink mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                  placeholder="Create a password"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-ink mb-1">
                  Confirm Password
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-mist-300 rounded focus:outline-none focus:border-tide-500 focus:ring-1 focus:ring-tide-500"
                  placeholder="Confirm your password"
                />
              </div>
            </>
          )}

          <button
            type="submit"
            className="mt-4 w-full bg-tide-600 text-white font-semibold py-2 px-4 rounded hover:bg-tide-700 transition-colors"
          >
            {isLogin ? 'Sign In' : 'Sign Up'}
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-ink-soft">
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <button 
            type="button" 
            onClick={() => {
              setIsLogin(!isLogin)
              setError('')
              setPassword('')
              setConfirmPassword('')
            }}
            className="text-tide-600 hover:text-tide-700 font-medium"
          >
            {isLogin ? 'Sign Up' : 'Sign In'}
          </button>
        </div>
      </div>
    </div>
  )
}
