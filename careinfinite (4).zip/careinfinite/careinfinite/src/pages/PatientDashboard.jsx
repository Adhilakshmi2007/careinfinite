import { useState } from 'react'
import { Link } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import Loading from '../components/ui/Loading'
import StatCard from '../components/ui/StatCard'
import SafetyNotice from '../components/ui/SafetyNotice'
import ProgressBar from '../components/ui/ProgressBar'
import TaskList from '../components/patient/TaskList'
import Timeline from '../components/patient/Timeline'
import Reminders from '../components/patient/Reminders'
import WarningSigns from '../components/patient/WarningSigns'
import Instructions from '../components/patient/Instructions'
import { useAsync } from '../hooks/useAsync'
import { getPatientById } from '../services/patientService'
import { countByStatus, progressPercent } from '../utils/tasks'

const DEMO_PATIENT_ID = 'p-001' // later: the logged-in patient's id

export default function PatientDashboard() {
  const { data: patient, loading, setData } = useAsync(() => getPatientById(DEMO_PATIENT_ID))
  const [filter, setFilter] = useState('all')

  if (loading) return <Loading text="Loading your care plan…" />
  if (!patient) return <p className="container-page py-12">We could not find your care plan. Please contact the hospital.</p>

  const counts = countByStatus(patient.tasks)
  const visible = filter === 'all' ? patient.tasks : patient.tasks.filter((t) => t.status === filter)

  function completeTask(id) {
    // Later: await updateTask(id, 'completed') in the service layer
    setData({ ...patient, tasks: patient.tasks.map((t) => (t.id === id ? { ...t, status: 'completed' } : t)) })
  }

  const tabs = [
    { key: 'all', label: 'All tasks', value: patient.tasks.length },
    { key: 'pending', label: 'Pending', value: counts.pending, tone: 'text-amber-700' },
    { key: 'completed', label: 'Completed', value: counts.completed, tone: 'text-leaf-700' },
    { key: 'needs_review', label: 'Needs review', value: counts.needs_review, tone: 'text-iris-700' },
  ]

  return (
    <div className="container-page space-y-8 py-10">
      <PageHeader title={`Hello, ${patient.name.split(' ')[0]}`} subtitle={`You went home from ${patient.ward} 3 days ago. Here is what comes next.`} />
      <SafetyNotice />

      <div className="card p-5">
        <div className="flex justify-between items-center mb-2">
          <p className="text-sm font-semibold">Your follow-up progress</p>
          <Link to="/upload" className="btn btn-primary text-sm px-4 py-1.5">
            Upload Summary
          </Link>
        </div>
        <ProgressBar value={progressPercent(patient.tasks)} label="Follow-up progress" />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tabs.map((t) => (
          <StatCard key={t.key} label={t.label} value={t.value} tone={t.tone} active={filter === t.key} onClick={() => setFilter(t.key)} />
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="card p-5" aria-labelledby="tasks-h">
            <h2 id="tasks-h" className="text-xl">Your tasks</h2>
            <TaskList tasks={visible} onComplete={completeTask} />
          </section>
          <section className="card p-5" aria-labelledby="inst-h">
            <h2 id="inst-h" className="mb-2 text-xl">Your instructions, in simple words</h2>
            <Instructions items={patient.instructions} />
          </section>
        </div>

        <div className="space-y-6">
          <WarningSigns signs={patient.warningSigns} />
          <section className="card p-5" aria-labelledby="rem-h">
            <h2 id="rem-h" className="mb-3 text-xl">Reminders</h2>
            <Reminders reminders={patient.reminders} />
          </section>
          <section className="card p-5" aria-labelledby="tl-h">
            <h2 id="tl-h" className="mb-4 text-xl">Timeline</h2>
            <Timeline events={patient.timeline} />
          </section>
        </div>
      </div>
    </div>
  )
}
