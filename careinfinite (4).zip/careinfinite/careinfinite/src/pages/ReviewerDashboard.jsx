import { useState } from 'react'
import PageHeader from '../components/layout/PageHeader'
import Loading from '../components/ui/Loading'
import StatCard from '../components/ui/StatCard'
import SafetyNotice from '../components/ui/SafetyNotice'
import ReviewCaseCard from '../components/reviewer/ReviewCaseCard'
import { useAsync } from '../hooks/useAsync'
import { getReviewCases, updateCaseStatus } from '../services/reviewService'

export default function ReviewerDashboard() {
  const { data: cases, loading, setData } = useAsync(() => getReviewCases())
  const [filter, setFilter] = useState('all')

  if (loading) return <Loading text="Loading cases…" />

  async function setStatus(id, status) {
    await updateCaseStatus(id, status)
    setData(cases.map((c) => (c.id === id ? { ...c, status } : c)))
  }

  const count = (s) => cases.filter((c) => c.status === s).length
  const visible = filter === 'all' ? cases : cases.filter((c) => c.status === filter)

  return (
    <div className="container-page space-y-8 py-10">
      <PageHeader
        title="Cases for review"
        subtitle="The AI was not sure about these items. Compare each one with the source text and resolve it."
      />
      <SafetyNotice>Reviewers confirm what the document says. They do not make diagnoses or treatment decisions here.</SafetyNotice>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="All cases" value={cases.length} active={filter === 'all'} onClick={() => setFilter('all')} />
        <StatCard label="Open" value={count('open')} tone="text-clay-700" active={filter === 'open'} onClick={() => setFilter('open')} />
        <StatCard label="In review" value={count('in_review')} tone="text-iris-700" active={filter === 'in_review'} onClick={() => setFilter('in_review')} />
        <StatCard label="Resolved" value={count('resolved')} tone="text-leaf-700" active={filter === 'resolved'} onClick={() => setFilter('resolved')} />
      </div>

      <div className="space-y-4">
        {visible.length ? (
          visible.map((c) => (
            <ReviewCaseCard key={c.id} item={c} onReview={(id) => setStatus(id, 'in_review')} onResolve={(id) => setStatus(id, 'resolved')} />
          ))
        ) : (
          <p className="card p-8 text-center text-ink-soft">No cases in this group.</p>
        )}
      </div>
    </div>
  )
}
