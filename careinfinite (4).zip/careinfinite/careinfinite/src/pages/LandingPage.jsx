import { Link } from 'react-router-dom'

const STEPS = [
  { title: 'Upload the discharge summary', text: 'Hospital staff add the paperwork a patient goes home with.' },
  { title: 'Turn it into a clear plan', text: 'Appointments, tests, reminders and warning signs are pulled out and written in simple language.' },
  { title: 'Keep following up', text: 'Patients tick off tasks, staff see who is falling behind, and unclear items go to a human reviewer.' },
]

const ROLES = [
  { title: 'Patients', text: 'A calm, plain-language list of what to do next and what to watch for.' },
  { title: 'Hospital staff', text: 'See follow-up progress for every discharged patient and spot overdue tasks early.' },
  { title: 'Reviewers', text: 'Check the items AI was unsure about, against the original source text.' },
]

function CareThread() {
  return (
    <svg viewBox="0 0 560 220" className="w-full" role="img" aria-label="A continuous line from hospital discharge to home to follow-up care">
      <path className="thread-draw" d="M30 150 C 110 40, 180 40, 230 110 S 350 190, 420 100 S 500 60, 530 90" fill="none" stroke="#4DB3BF" strokeWidth="5" strokeLinecap="round" />
      {[[30, 150, 'Discharge'], [230, 110, 'Home'], [420, 100, 'Follow-up'], [530, 90, 'Recovery']].map(([x, y, t]) => (
        <g key={t}>
          <circle cx={x} cy={y} r="9" fill="#0B3A40" stroke="#4DB3BF" strokeWidth="3" />
          <text x={x} y={y + 30} textAnchor="middle" fontSize="14" fontWeight="600" fill="#E6F0EE">{t}</text>
        </g>
      ))}
    </svg>
  )
}

export default function LandingPage() {
  return (
    <>
      <section className="bg-pine-900 text-white">
        <div className="container-page grid items-center gap-10 py-16 lg:grid-cols-2 lg:py-24">
          <div>
            <h1 className="text-4xl font-semibold leading-tight !text-white sm:text-5xl">Care that continues beyond discharge.</h1>
            <p className="mt-5 max-w-lg text-lg text-mist-200">
              Going home is when many patients feel most alone. CareInfinite turns a discharge summary into a clear follow-up plan that patients, hospital staff and reviewers can all see.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/roles" className="btn bg-tide-400 text-pine-900 hover:bg-tide-500">Choose your role</Link>
              <a href="#how" className="btn border border-white/30 text-white hover:bg-white/10">See how it works</a>
            </div>
          </div>
          <CareThread />
        </div>
      </section>

      <section id="how" className="container-page py-16">
        <h2 className="text-3xl">How it works</h2>
        <ol className="mt-8 grid gap-5 md:grid-cols-3">
          {STEPS.map((s, i) => (
            <li key={s.title} className="card p-6">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-mist-100 text-sm font-bold text-tide-700">{i + 1}</span>
              <h3 className="mt-4 font-sans text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-ink-soft">{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="bg-white">
        <div className="container-page py-16">
          <h2 className="text-3xl">Built for everyone in the discharge journey</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            {ROLES.map((r) => (
              <div key={r.title} className="rounded-2xl bg-mist-50 p-6">
                <h3 className="font-sans text-lg font-semibold">{r.title}</h3>
                <p className="mt-2 text-sm text-ink-soft">{r.text}</p>
              </div>
            ))}
          </div>
          <p className="mt-10 max-w-3xl rounded-xl border border-mist-200 p-4 text-sm text-ink-soft">
            <strong className="text-pine-900">What CareInfinite does not do:</strong> it does not diagnose, prescribe, change medication, recommend treatment, or guarantee provider matches. It only organises what is already in the discharge paperwork.
          </p>
        </div>
      </section>
    </>
  )
}
