import { useState } from 'react'
import { Link } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import Loading from '../components/ui/Loading'
import StatCard from '../components/ui/StatCard'
import SafetyNotice from '../components/ui/SafetyNotice'
import PatientTable from '../components/staff/PatientTable'
import AttentionList from '../components/staff/AttentionList'
import { useAsync } from '../hooks/useAsync'
import { getPatients } from '../services/patientService'
import { countByStatus, progressPercent } from '../utils/tasks'

export default function StaffDashboard() {
  const { data: patients, loading } = useAsync(() => getPatients())
  const [filter, setFilter] = useState('all')
  const [selectedId, setSelectedId] = useState(null)
  const [remindedIds, setRemindedIds] = useState([])

  if (loading) return <Loading text="Loading patients…" />

  const all = patients.map((p) => ({ p, c: countByStatus(p.tasks) }))
  const totals = {
    overdue: all.reduce((n, x) => n + x.c.overdue, 0),
    review: all.reduce((n, x) => n + x.c.needs_review, 0),
    avg: Math.round(patients.reduce((n, p) => n + progressPercent(p.tasks), 0) / patients.length),
  }

  const filtered = patients.filter((p) => {
    const c = countByStatus(p.tasks)
    if (filter === 'overdue') return c.overdue > 0
    if (filter === 'needs_review') return c.needs_review > 0
    return true
  })
  const selected = patients.find((p) => p.id === selectedId)

  return (
    <div className="container-page space-y-8 py-10">
      <PageHeader
        title="Discharged patients"
        subtitle="Follow-up progress across your recent discharges."
        action={<Link to="/upload" className="btn btn-primary">Upload discharge summary</Link>}
      />
      <SafetyNotice>This dashboard tracks follow-up tasks only. Clinical decisions stay with the care team.</SafetyNotice>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="All patients" value={patients.length} active={filter === 'all'} onClick={() => setFilter('all')} />
        <StatCard label="Avg. follow-up progress" value={`${totals.avg}%`} />
        <StatCard label="Overdue tasks" value={totals.overdue} tone="text-clay-700" active={filter === 'overdue'} onClick={() => setFilter('overdue')} />
        <StatCard label="Needs review" value={totals.review} tone="text-iris-700" active={filter === 'needs_review'} onClick={() => setFilter('needs_review')} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <section className="card p-5 lg:col-span-2" aria-labelledby="pl-h">
          <h2 id="pl-h" className="mb-3 text-xl">Patient list</h2>
          {filtered.length ? (
            <PatientTable
              patients={filtered}
              selectedId={selectedId}
              onSelect={setSelectedId}
              remindedIds={remindedIds}
              onRemind={(id) => setRemindedIds((ids) => [...ids, id])}
            />
          ) : (
            <p className="py-6 text-center text-ink-soft">No patients match this filter.</p>
          )}
        </section>

        <aside className="card p-5" aria-labelledby="att-h">
          <h2 id="att-h" className="text-xl">{selected ? selected.name : 'Select a patient'}</h2>
          {selected ? (
            <>
              <p className="mb-4 mt-1 text-sm text-ink-soft">{selected.careTeam}</p>
              <AttentionList patient={selected} />
            </>
          ) : (
            <p className="mt-2 text-sm text-ink-soft">Choose a patient in the list to see their open tasks.</p>
          )}
        </aside>
      </div>
    </div>
  )
}
