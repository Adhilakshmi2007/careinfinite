import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import FileDropzone from '../components/upload/FileDropzone'
import ExtractionResults from '../components/upload/ExtractionResults'
import { analyzeDischargeSummary } from '../services/dischargeService'

export default function UploadPage() {
  const navigate = useNavigate()
  const [mode, setMode] = useState('file') // 'file' | 'text'
  const [file, setFile] = useState(null)
  const [text, setText] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')

  const canAnalyze = mode === 'file' ? !!file : text.trim().length > 0

  async function analyze() {
    setAnalyzing(true)
    setError('')
    try {
      setResult(await analyzeDischargeSummary({ file: mode === 'file' ? file : null, text: mode === 'text' ? text : '' }))
    } catch {
      setError('Analysis did not finish. Check your connection and try again.')
    } finally {
      setAnalyzing(false)
    }
  }

  const tab = (key) =>
    `rounded-lg px-4 py-2 text-sm font-semibold ${mode === key ? 'bg-pine-900 text-white' : 'text-ink-soft hover:bg-mist-100'}`

  return (
    <div className="container-page max-w-3xl space-y-6 py-10">
      <button 
        onClick={() => navigate(-1)} 
        className="text-pine-700 hover:text-pine-900 font-medium text-sm flex items-center gap-1 mb-2"
      >
        ← Back
      </button>
      <PageHeader title="Upload a discharge summary" subtitle="Add the document and CareInfinite will organise it into a follow-up plan." />

      <div className="card space-y-4 p-5">
        <div className="flex gap-2" role="tablist" aria-label="Input method">
          <button role="tab" aria-selected={mode === 'file'} className={tab('file')} onClick={() => setMode('file')}>Upload file</button>
          <button role="tab" aria-selected={mode === 'text'} className={tab('text')} onClick={() => setMode('text')}>Paste text</button>
        </div>

        {mode === 'file' ? (
          <FileDropzone file={file} onFile={setFile} />
        ) : (
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={9}
            placeholder="Paste the discharge summary text here…"
            aria-label="Discharge summary text"
            className="w-full rounded-xl border border-mist-200 bg-mist-50 p-3 text-sm focus:border-tide-600 focus:outline-none"
          />
        )}

        <button className="btn btn-primary w-full sm:w-auto" disabled={!canAnalyze || analyzing} onClick={analyze}>
          {analyzing ? 'Analyzing…' : 'Analyze summary'}
        </button>
        {error && <p className="text-sm text-clay-700" role="alert">{error}</p>}
      </div>

      {result && <ExtractionResults result={result} />}
    </div>
  )
}
