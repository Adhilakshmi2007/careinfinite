import ProgressBar from '../ui/ProgressBar'
import { countByStatus, progressPercent } from '../../utils/tasks'
import { formatDate } from '../../utils/dates'

export default function PatientTable({ patients, selectedId, onSelect, remindedIds, onRemind }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-left text-sm">
        <thead className="text-xs text-ink-faint">
          <tr className="border-b border-mist-100">
            <th className="py-2 pr-3 font-medium">Patient</th>
            <th className="py-2 pr-3 font-medium">Discharged</th>
            <th className="w-48 py-2 pr-3 font-medium">Follow-up progress</th>
            <th className="py-2 pr-3 font-medium">Flags</th>
            <th className="py-2" />
          </tr>
        </thead>
        <tbody>
          {patients.map((p) => {
            const c = countByStatus(p.tasks)
            const selected = p.id === selectedId
            return (
              <tr key={p.id} className={`border-b border-mist-100 last:border-0 ${selected ? 'bg-mist-50' : ''}`}>
                <td className="py-3 pr-3">
                  <button className="text-left" onClick={() => onSelect(p.id)}>
                    <span className="block font-semibold text-ink hover:text-tide-700">{p.name}</span>
                    <span className="text-xs text-ink-faint">{p.age} yrs · {p.ward}</span>
                  </button>
                </td>
                <td className="py-3 pr-3 text-ink-soft">{formatDate(p.dischargeDate)}</td>
                <td className="py-3 pr-3"><ProgressBar value={progressPercent(p.tasks)} label={`${p.name} follow-up progress`} /></td>
                <td className="py-3 pr-3">
                  <div className="flex flex-wrap gap-1.5">
                    {c.overdue > 0 && <span className="rounded-full bg-clay-50 px-2 py-0.5 text-xs font-semibold text-clay-700">{c.overdue} overdue</span>}
                    {c.needs_review > 0 && <span className="rounded-full bg-iris-50 px-2 py-0.5 text-xs font-semibold text-iris-700">{c.needs_review} review</span>}
                    {c.overdue === 0 && c.needs_review === 0 && <span className="text-xs text-ink-faint">On track</span>}
                  </div>
                </td>
                <td className="py-3 text-right">
                  {c.overdue > 0 && (
                    <button className="btn btn-secondary !px-3 !py-1.5" disabled={remindedIds.includes(p.id)} onClick={() => onRemind(p.id)}>
                      {remindedIds.includes(p.id) ? 'Reminder sent' : 'Send reminder'}
                    </button>
                  )}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
