import StatusBadge from '../ui/StatusBadge'
import { dueLabel, isOverdue } from '../../utils/dates'

// Pending/overdue/needs-review tasks for ONE patient (staff side panel)
export default function AttentionList({ patient }) {
  const items = patient.tasks.filter((t) => t.status !== 'completed')
  if (!items.length) return <p className="text-sm text-ink-soft">All follow-up tasks are complete.</p>
  return (
    <ul className="space-y-3">
      {items.map((t) => (
        <li key={t.id} className="rounded-lg bg-mist-50 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-sm font-semibold">{t.title}</span>
            <StatusBadge status={isOverdue(t) ? 'overdue' : t.status} />
          </div>
          <p className="mt-1 text-xs text-ink-faint">{dueLabel(t.due)}</p>
        </li>
      ))}
    </ul>
  )
}
