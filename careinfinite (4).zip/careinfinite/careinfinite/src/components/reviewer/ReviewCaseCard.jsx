import StatusBadge from '../ui/StatusBadge'

export default function ReviewCaseCard({ item, onReview, onResolve }) {
  const pct = Math.round(item.confidence * 100)
  const low = item.confidence < 0.6
  return (
    <article className="card p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-sm text-ink-faint">{item.patientName}</p>
          <h3 className="font-sans text-lg font-semibold">{item.field}</h3>
        </div>
        <div className="flex items-center gap-2">
          <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${low ? 'bg-clay-50 text-clay-700' : 'bg-amber-50 text-amber-700'}`}>
            AI confidence {pct}%
          </span>
          <StatusBadge status={item.status} />
        </div>
      </div>

      <dl className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <dt className="text-xs font-semibold text-ink-faint">What the AI extracted</dt>
          <dd className="mt-1 text-sm">{item.extracted}</dd>
          <dt className="mt-3 text-xs font-semibold text-ink-faint">Why it is uncertain</dt>
          <dd className="mt-1 text-sm text-ink-soft">{item.reason}</dd>
        </div>
        <div className="rounded-xl border-l-4 border-tide-500 bg-mist-50 p-3">
          <dt className="text-xs font-semibold text-ink-faint">Evidence · {item.evidence.source}</dt>
          <dd className="mt-1 font-mono text-sm text-ink">“{item.evidence.quote}”</dd>
        </div>
      </dl>

      {item.status !== 'resolved' && (
        <div className="mt-4 flex flex-wrap gap-2">
          {item.status === 'open' && <button className="btn btn-secondary" onClick={() => onReview(item.id)}>Start review</button>}
          <button className="btn btn-primary" onClick={() => onResolve(item.id)}>Resolve</button>
        </div>
      )}
    </article>
  )
}
