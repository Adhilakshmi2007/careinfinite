import { Link, NavLink, useNavigate } from 'react-router-dom'
import Logo from '../ui/Logo'
import { ROLES, useRole } from '../../context/RoleContext'

export default function Navbar() {
  const { role, setRole } = useRole()
  const navigate = useNavigate()
  const link = ({ isActive }) =>
    `rounded-md px-3 py-1.5 text-sm font-medium ${isActive ? 'bg-mist-100 text-pine-900' : 'text-ink-soft hover:text-pine-900'}`

  return (
    <header className="sticky top-0 z-20 border-b border-mist-200 bg-white/90 backdrop-blur">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Link to="/" aria-label="CareInfinite home"><Logo /></Link>
        <nav className="flex items-center gap-1 overflow-x-auto" aria-label="Main">
          {role === 'staff' && <NavLink to="/upload" className={link}>Upload summary</NavLink>}
          {role ? (
            <>
              <NavLink to={ROLES[role].path} className={link}>{ROLES[role].label}</NavLink>
              <button className="btn btn-ghost !py-1.5" onClick={() => { setRole(null); navigate('/roles') }}>
                Switch role
              </button>
            </>
          ) : (
            <Link to="/roles" className="btn btn-primary !py-2">Get started</Link>
          )}
        </nav>
      </div>
    </header>
  )
}
