export default function Footer() {
  return (
    <footer className="border-t border-mist-200 bg-white">
      <div className="container-page py-6 text-xs leading-relaxed text-ink-faint">
        Hackathon prototype · all patient data on screen is synthetic. CareInfinite does not diagnose, prescribe,
        change medication, recommend treatment, or guarantee provider matches.
      </div>
    </footer>
  )
}
