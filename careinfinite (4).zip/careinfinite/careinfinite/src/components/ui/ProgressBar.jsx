export default function ProgressBar({ value, label }) {
  return (
    <div className="flex items-center gap-3">
      <div
        className="h-2 w-full overflow-hidden rounded-full bg-mist-100"
        role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100} aria-label={label ?? 'Progress'}
      >
        <div className="h-full rounded-full bg-tide-600 transition-all" style={{ width: `${value}%` }} />
      </div>
      <span className="w-10 text-right text-xs font-semibold text-ink-soft">{value}%</span>
    </div>
  )
}
