// Shown on every dashboard. CareInfinite organises information — it never gives medical advice.
export default function SafetyNotice({ children }) {
  return (
    <div className="flex gap-3 rounded-xl border border-tide-400/40 bg-tide-400/10 p-3 text-sm text-pine-800" role="note">
      <svg className="mt-0.5 h-5 w-5 shrink-0 text-tide-700" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
      </svg>
      <p>{children ?? 'CareInfinite organises what is already in your discharge paperwork. It does not diagnose, prescribe, change medicines or give treatment advice. For any health concern, contact your care team.'}</p>
    </div>
  )
}
