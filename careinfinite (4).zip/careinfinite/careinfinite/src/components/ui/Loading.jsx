export default function Loading({ text = 'Loading…' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-20 text-ink-soft" role="status">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-mist-200 border-t-tide-600" />
      {text}
    </div>
  )
}
