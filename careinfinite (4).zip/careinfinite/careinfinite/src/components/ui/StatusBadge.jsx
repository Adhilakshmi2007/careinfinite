// One badge component for every task/case status in the app.
const STYLES = {
  pending: 'bg-amber-50 text-amber-700',
  completed: 'bg-leaf-50 text-leaf-700',
  needs_review: 'bg-iris-50 text-iris-700',
  overdue: 'bg-clay-50 text-clay-700',
  open: 'bg-clay-50 text-clay-700',
  in_review: 'bg-iris-50 text-iris-700',
  resolved: 'bg-leaf-50 text-leaf-700',
}
const LABELS = {
  pending: 'Pending',
  completed: 'Completed',
  needs_review: 'Needs review',
  overdue: 'Overdue',
  open: 'Open',
  in_review: 'In review',
  resolved: 'Resolved',
}

export default function StatusBadge({ status }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${STYLES[status]}`}>
      {LABELS[status] ?? status}
    </span>
  )
}
