export default function StatCard({ label, value, tone = 'text-pine-900', active = false, onClick }) {
  const Tag = onClick ? 'button' : 'div'
  return (
    <Tag
      onClick={onClick}
      className={`card p-4 text-left ${onClick ? 'transition-colors hover:bg-mist-50' : ''} ${active ? 'ring-2 ring-tide-600' : ''}`}
    >
      <p className={`font-display text-3xl font-semibold ${tone}`}>{value}</p>
      <p className="mt-1 text-sm text-ink-soft">{label}</p>
    </Tag>
  )
}
