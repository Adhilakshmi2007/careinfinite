export default function Logo({ light = false }) {
  return (
    <span className="inline-flex items-center gap-2">
      <svg width="30" height="30" viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" rx="14" fill={light ? '#17606A' : '#0B3A40'} />
        <path d="M32 32c-4-8-8-10-12-10a10 10 0 0 0 0 20c4 0 8-2 12-10s8-10 12-10a10 10 0 0 1 0 20c-4 0-8-2-12-10z" fill="none" stroke="#4DB3BF" strokeWidth="4.5" strokeLinecap="round" />
      </svg>
      <span className={`font-display text-xl font-semibold ${light ? 'text-white' : 'text-pine-900'}`}>CareInfinite</span>
    </span>
  )
}
