import StatusBadge from '../ui/StatusBadge'
import { dueLabel, isOverdue } from '../../utils/dates'

export default function TaskList({ tasks, onComplete }) {
  if (!tasks.length) return <p className="py-6 text-center text-ink-soft">Nothing here right now.</p>
  return (
    <ul className="divide-y divide-mist-100">
      {tasks.map((t) => {
        const status = isOverdue(t) ? 'overdue' : t.status
        return (
          <li key={t.id} className="flex flex-wrap items-start justify-between gap-3 py-4">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className={`font-sans text-base font-semibold ${t.status === 'completed' ? 'text-ink-faint line-through' : 'text-ink'}`}>{t.title}</h3>
                <StatusBadge status={status} />
              </div>
              <p className="mt-1 text-sm text-ink-soft">{t.detail}</p>
              <p className="mt-1 text-xs text-ink-faint">{t.category} · {t.status === 'completed' ? 'Done' : dueLabel(t.due)}</p>
            </div>
            {t.status === 'pending' && (
              <button className="btn btn-secondary" onClick={() => onComplete(t.id)}>Mark done</button>
            )}
          </li>
        )
      })}
    </ul>
  )
}
