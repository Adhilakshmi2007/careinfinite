export default function WarningSigns({ signs }) {
  return (
    <section className="rounded-2xl border border-amber-500/40 bg-amber-50 p-5" aria-labelledby="warn-h">
      <h2 id="warn-h" className="text-xl">Warning signs to watch for</h2>
      <p className="mt-1 text-sm text-amber-700">These come from your discharge paperwork.</p>
      <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-ink">
        {signs.map((s) => <li key={s}>{s}</li>)}
      </ul>
      <p className="mt-4 rounded-lg bg-white/70 p-3 text-sm font-semibold text-clay-700">
        If you notice any of these, contact your care team straight away. In an emergency, call your local emergency number.
      </p>
    </section>
  )
}
