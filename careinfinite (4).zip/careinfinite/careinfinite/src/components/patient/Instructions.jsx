import { useState } from 'react'

// Shows plain-language wording first; patient can toggle the original medical wording.
export default function Instructions({ items }) {
  const [showOriginal, setShowOriginal] = useState(false)
  return (
    <div>
      <button className="btn btn-ghost mb-2 !px-2" onClick={() => setShowOriginal((v) => !v)} aria-pressed={showOriginal}>
        {showOriginal ? 'Hide original wording' : 'Show original wording'}
      </button>
      <ul className="space-y-4">
        {items.map((i) => (
          <li key={i.id} className="rounded-xl bg-mist-50 p-4">
            <p className="text-base leading-relaxed text-ink">{i.simple}</p>
            {showOriginal && (
              <p className="mt-2 border-t border-mist-200 pt-2 text-xs italic text-ink-faint">
                Original: {i.original}
              </p>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}
