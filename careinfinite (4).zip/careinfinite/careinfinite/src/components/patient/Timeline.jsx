import { formatDate } from '../../utils/dates'

const DOT = {
  done: 'bg-leaf-600 border-leaf-600',
  current: 'bg-white border-tide-600 ring-4 ring-tide-400/30',
  upcoming: 'bg-white border-mist-200',
}

export default function Timeline({ events }) {
  return (
    <ol className="relative ml-2 border-l-2 border-mist-200">
      {events.map((e) => (
        <li key={e.id} className="relative pb-6 pl-6 last:pb-0">
          <span className={`absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 ${DOT[e.status]}`} />
          <p className={`text-sm font-semibold ${e.status === 'upcoming' ? 'text-ink-soft' : 'text-ink'}`}>{e.label}</p>
          <p className="text-xs text-ink-faint">{formatDate(e.date)}{e.status === 'current' && ' · Today'}</p>
        </li>
      ))}
    </ol>
  )
}
