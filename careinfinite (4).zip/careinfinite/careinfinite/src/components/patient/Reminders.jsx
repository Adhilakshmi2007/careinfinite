export default function Reminders({ reminders }) {
  return (
    <ul className="space-y-3">
      {reminders.map((r) => (
        <li key={r.id} className="flex gap-3">
          <span className="w-20 shrink-0 text-sm font-semibold text-tide-700">{r.time}</span>
          <span className="text-sm text-ink-soft">{r.text}</span>
        </li>
      ))}
    </ul>
  )
}
