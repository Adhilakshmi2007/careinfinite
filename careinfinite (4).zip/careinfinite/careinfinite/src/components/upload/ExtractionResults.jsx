export default function ExtractionResults({ result }) {
  const reviewCount = result.sections.flatMap((s) => s.items).filter((i) => i.needsReview).length
  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h2 className="text-2xl">Extracted from the summary</h2>
        <p className="mt-1 text-sm text-ink-soft">{result.patient.name} · {result.patient.age} yrs · {result.patient.admissionReason}</p>
        {reviewCount > 0 && (
          <p className="mt-3 rounded-lg bg-iris-50 p-3 text-sm font-medium text-iris-700">
            {reviewCount} item{reviewCount > 1 ? 's' : ''} marked “Needs review” and will go to a human reviewer. Nothing was guessed.
          </p>
        )}
      </div>
      {result.sections.map((s) => (
        <section key={s.id} className="card p-5">
          <h3 className="text-lg">{s.title}</h3>
          {s.note && <p className="mt-1 text-xs text-ink-faint">{s.note}</p>}
          <ul className="mt-3 divide-y divide-mist-100">
            {s.items.map((i) => (
              <li key={i.text} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                <div>
                  <p className="text-sm font-semibold">{i.text}</p>
                  <p className="text-xs text-ink-faint">{i.detail}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-ink-faint">{Math.round(i.confidence * 100)}%</span>
                  {i.needsReview && <span className="rounded-full bg-iris-50 px-2.5 py-0.5 text-xs font-semibold text-iris-700">Needs review</span>}
                </div>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  )
}
