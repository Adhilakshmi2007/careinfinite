import { useRef, useState } from 'react'

const ACCEPT = '.pdf,.docx,.txt'
const ALLOWED = ['pdf', 'docx', 'txt']

export default function FileDropzone({ file, onFile }) {
  const inputRef = useRef(null)
  const [dragging, setDragging] = useState(false)
  const [error, setError] = useState('')

  function handle(f) {
    if (!f) return
    const ext = f.name.split('.').pop().toLowerCase()
    if (!ALLOWED.includes(ext)) {
      setError('This file type is not supported. Upload a PDF, DOCX or TXT file.')
      return
    }
    setError('')
    onFile(f)
  }

  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); handle(e.dataTransfer.files[0]) }}
        className={`rounded-2xl border-2 border-dashed p-8 text-center transition-colors ${dragging ? 'border-tide-600 bg-tide-400/10' : 'border-mist-200 bg-mist-50'}`}
      >
        <p className="font-semibold text-pine-900">Drag a discharge summary here</p>
        <p className="mt-1 text-sm text-ink-soft">PDF, DOCX or TXT</p>
        <button type="button" className="btn btn-secondary mt-4" onClick={() => inputRef.current?.click()}>Choose file</button>
        <input ref={inputRef} type="file" accept={ACCEPT} className="sr-only" aria-label="Choose discharge summary file" onChange={(e) => handle(e.target.files[0])} />
      </div>
      {error && <p className="mt-2 text-sm text-clay-700" role="alert">{error}</p>}
      {file && (
        <div className="mt-3 flex items-center justify-between rounded-lg border border-mist-200 bg-white px-3 py-2 text-sm">
          <span className="truncate font-medium">{file.name} <span className="text-ink-faint">({Math.max(1, Math.round(file.size / 1024))} KB)</span></span>
          <button className="btn btn-ghost !py-1" onClick={() => onFile(null)}>Remove</button>
        </div>
      )}
    </div>
  )
}
