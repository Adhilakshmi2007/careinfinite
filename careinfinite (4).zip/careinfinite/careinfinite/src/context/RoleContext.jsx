import { createContext, useContext, useState } from 'react'

// Which role the visitor picked. Real login/auth can replace this later.
export const ROLES = {
  patient: { label: 'Patient', path: '/patient' },
  staff: { label: 'Hospital Staff', path: '/staff' },
  reviewer: { label: 'Reviewer', path: '/reviewer' },
}

const RoleContext = createContext(null)

export function RoleProvider({ children }) {
  const [role, setRole] = useState(null)
  return <RoleContext.Provider value={{ role, setRole }}>{children}</RoleContext.Provider>
}

export function useRole() {
  const ctx = useContext(RoleContext)
  if (!ctx) throw new Error('useRole must be used inside <RoleProvider>')
  return ctx
}
