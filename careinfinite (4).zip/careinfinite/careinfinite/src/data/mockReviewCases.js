// ⚠️ SYNTHETIC DATA. These represent items an AI model was NOT confident about.
// Reviewers confirm what the document actually says — they do not make clinical decisions here.
export const mockReviewCases = [
  {
    id: 'c-101',
    patientName: 'Lakshmi Pillai',
    field: 'Follow-up date',
    extracted: 'Pulmonology review in 1–2 weeks (no exact date)',
    confidence: 0.46,
    reason: 'The document gives a range, not a date. Scheduling needs a confirmed date.',
    evidence: { source: 'Discharge Summary · page 2 · "Follow-up" section', quote: 'Review in pulmonology clinic in 1–2 weeks. Bring oxygen log.' },
    status: 'open',
  },
  {
    id: 'c-102',
    patientName: 'Fatima Sheikh',
    field: 'Medication list entry',
    extracted: 'Entry 4 could not be read clearly',
    confidence: 0.38,
    reason: 'Handwritten addendum is partly illegible. The system did not guess.',
    evidence: { source: 'Scanned addendum · page 3', quote: '[illegible] — as before, morning' },
    status: 'open',
  },
  {
    id: 'c-103',
    patientName: 'Meera Nair',
    field: 'Salt (sodium) limit',
    extracted: 'Two different limits appear in the document',
    confidence: 0.52,
    reason: 'The diet section and the nursing notes disagree. Needs the care team to state which applies.',
    evidence: { source: 'Discharge Summary · page 1 and page 4', quote: 'Page 1: "low-sodium diet"  |  Page 4: "strict sodium restriction"' },
    status: 'in_review',
  },
  {
    id: 'c-104',
    patientName: 'Arjun Menon',
    field: 'Physiotherapy frequency',
    extracted: '3 times per week',
    confidence: 0.71,
    reason: 'Matches the text, but the phrase "as tolerated" was also present.',
    evidence: { source: 'Discharge Summary · page 2 · "Rehabilitation"', quote: 'Physiotherapy 3x/week as tolerated for 6 weeks.' },
    status: 'resolved',
  },
]
