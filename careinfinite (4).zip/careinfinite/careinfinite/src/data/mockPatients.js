// ⚠️ SYNTHETIC DATA ONLY — no real patients. Replace with API/database later.
// Task statuses: 'pending' | 'completed' | 'needs_review'
// "Overdue" is calculated automatically from a pending task's due date.
import { daysFromNow } from '../utils/dates'

export const mockPatients = [
  {
    id: 'p-001',
    name: 'Arun Kumar',
    age: 67,
    ward: 'Cardiology',
    dischargeDate: daysFromNow(-3),
    careTeam: 'Dr. R. Iyer · Nurse Anita',
    tasks: [
      { id: 't-1', title: 'Weigh yourself each morning', detail: 'Write the number down. Share it at your follow-up visit.', due: daysFromNow(0), status: 'pending', category: 'Daily check' },
      { id: 't-2', title: 'Follow-up visit with Dr. Iyer', detail: 'Cardiology outpatient, Block B. Bring your discharge papers.', due: daysFromNow(4), status: 'pending', category: 'Appointment' },
      { id: 't-3', title: 'Blood test (kidney function)', detail: 'Visit the lab as listed in your discharge summary.', due: daysFromNow(6), status: 'pending', category: 'Test' },
      { id: 't-4', title: 'Nurse check-in call', detail: 'A nurse will call to ask how you are feeling.', due: daysFromNow(-2), status: 'completed', category: 'Check-in' },
      { id: 't-5', title: 'Collect medicines from pharmacy', detail: 'Medicines are as listed on your discharge medication sheet.', due: daysFromNow(-3), status: 'completed', category: 'Pharmacy' },
      { id: 't-6', title: 'Confirm diet advice with care team', detail: 'The paperwork gives two different salt limits. Your care team is confirming which applies.', due: daysFromNow(1), status: 'needs_review', category: 'Clarification' },
    ],
    timeline: [
      { id: 'e-1', label: 'Discharged from hospital', date: daysFromNow(-3), status: 'done' },
      { id: 'e-2', label: 'Nurse check-in call', date: daysFromNow(-2), status: 'done' },
      { id: 'e-3', label: 'Daily weight check', date: daysFromNow(0), status: 'current' },
      { id: 'e-4', label: 'Follow-up visit with Dr. Iyer', date: daysFromNow(4), status: 'upcoming' },
      { id: 'e-5', label: 'Blood test', date: daysFromNow(6), status: 'upcoming' },
      { id: 'e-6', label: '30-day review', date: daysFromNow(27), status: 'upcoming' },
    ],
    reminders: [
      { id: 'r-1', time: '8:00 AM', text: 'Weigh yourself and write it down' },
      { id: 'r-2', time: '9:00 AM', text: 'Take morning medicines exactly as on your medication sheet' },
      { id: 'r-3', time: '8:00 PM', text: 'Take evening medicines exactly as on your medication sheet' },
      { id: 'r-4', time: 'In 4 days', text: 'Follow-up visit — bring your discharge papers' },
    ],
    warningSigns: [
      'Sudden or worsening shortness of breath',
      'Chest pain or pressure',
      'Fainting or feeling very dizzy',
      'Fast weight gain or new swelling in the legs',
      'Any symptom your discharge papers tell you to report',
    ],
    instructions: [
      { id: 'i-1', original: 'Maintain strict sodium restriction; monitor daily weights and report fluid retention.', simple: 'Eat less salt. Weigh yourself every morning. Tell your care team if you are gaining weight quickly or your legs are swelling.' },
      { id: 'i-2', original: 'Ambulate as tolerated; avoid strenuous exertion for 2 weeks.', simple: 'Walk a little each day if you feel able. Do not do heavy exercise for the next 2 weeks.' },
      { id: 'i-3', original: 'Continue medications per discharge medication reconciliation.', simple: 'Keep taking your medicines exactly as written on your medication sheet. Do not change or stop any medicine on your own — ask your care team first.' },
    ],
  },
  {
    id: 'p-002',
    name: 'Arjun Menon',
    age: 54,
    ward: 'Orthopaedics',
    dischargeDate: daysFromNow(-8),
    careTeam: 'Dr. S. Kapoor · Nurse Divya',
    tasks: [
      { id: 't-1', title: 'Wound dressing check', detail: 'Dressing review at clinic.', due: daysFromNow(-4), status: 'pending', category: 'Appointment' },
      { id: 't-2', title: 'Physiotherapy session 1', detail: 'Physio dept, Level 2.', due: daysFromNow(-2), status: 'completed', category: 'Therapy' },
      { id: 't-3', title: 'Physiotherapy session 2', detail: 'Physio dept, Level 2.', due: daysFromNow(-1), status: 'pending', category: 'Therapy' },
      { id: 't-4', title: 'X-ray follow-up', detail: 'Imaging as listed in discharge summary.', due: daysFromNow(3), status: 'pending', category: 'Test' },
    ],
  },
  {
    id: 'p-003',
    name: 'Fatima Sheikh',
    age: 72,
    ward: 'General Medicine',
    dischargeDate: daysFromNow(-5),
    careTeam: 'Dr. P. Rao · Nurse Kiran',
    tasks: [
      { id: 't-1', title: 'Nurse check-in call', detail: 'Phone call.', due: daysFromNow(-3), status: 'completed', category: 'Check-in' },
      { id: 't-2', title: 'Blood sugar log review', detail: 'Bring your log to the visit.', due: daysFromNow(2), status: 'pending', category: 'Daily check' },
      { id: 't-3', title: 'Medication list unclear', detail: 'Two entries need clarification from the discharge summary.', due: daysFromNow(0), status: 'needs_review', category: 'Clarification' },
      { id: 't-4', title: 'Follow-up visit', detail: 'General medicine OPD.', due: daysFromNow(5), status: 'pending', category: 'Appointment' },
      { id: 't-5', title: 'Dietitian session', detail: 'Booked via hospital.', due: daysFromNow(7), status: 'pending', category: 'Appointment' },
    ],
  },
  {
    id: 'p-004',
    name: 'Rohan Das',
    age: 41,
    ward: 'Surgery',
    dischargeDate: daysFromNow(-12),
    careTeam: 'Dr. L. Thomas · Nurse Sana',
    tasks: [
      { id: 't-1', title: 'Stitch removal visit', detail: 'Surgical clinic.', due: daysFromNow(-6), status: 'completed', category: 'Appointment' },
      { id: 't-2', title: 'Nurse check-in call', detail: 'Phone call.', due: daysFromNow(-9), status: 'completed', category: 'Check-in' },
      { id: 't-3', title: 'Final review visit', detail: 'Surgical clinic.', due: daysFromNow(2), status: 'pending', category: 'Appointment' },
    ],
  },
  {
    id: 'p-005',
    name: 'Lakshmi Pillai',
    age: 79,
    ward: 'Pulmonology',
    dischargeDate: daysFromNow(-2),
    careTeam: 'Dr. N. Shah · Nurse Priya',
    tasks: [
      { id: 't-1', title: 'Nurse check-in call', detail: 'Phone call.', due: daysFromNow(-1), status: 'pending', category: 'Check-in' },
      { id: 't-2', title: 'Oxygen reading log', detail: 'Record daily readings.', due: daysFromNow(0), status: 'pending', category: 'Daily check' },
      { id: 't-3', title: 'Follow-up date unclear', detail: 'Summary says "review in 1–2 weeks". Needs a confirmed date.', due: daysFromNow(1), status: 'needs_review', category: 'Clarification' },
    ],
  },
]
