// ⚠️ SYNTHETIC — what a discharge-summary analysis could return.
// Everything here is *copied/organised from the document*, never invented or recommended by the app.
export const mockExtraction = {
  patient: { name: 'Arun Kumar', age: 67, admissionReason: 'Admission for congestive heart failure exacerbation' },
  sections: [
    {
      id: 'followups',
      title: 'Follow-up appointments',
      items: [
        { text: 'Cardiology clinic with Dr. Iyer', detail: 'In 4 days (Outpatient Block B)', confidence: 0.98 },
        { text: 'Pulmonology review', detail: '"1–2 weeks" — exact date not stated', confidence: 0.46, needsReview: true },
        { text: 'Nurse check-in call', detail: 'Within 24-48 hours post-discharge', confidence: 0.92 },
      ],
    },
    {
      id: 'tests',
      title: 'Tests to complete',
      items: [
        { text: 'Blood test — Kidney function (Creatinine, Electrolytes)', detail: 'Within 7 days', confidence: 0.95 },
        { text: 'Echocardiogram', detail: 'Schedule before next Cardiology visit', confidence: 0.89 },
      ],
    },
    {
      id: 'meds',
      title: 'Medicines listed in the document',
      note: 'Shown exactly as written. CareInfinite does not add, change or advise on medicines.',
      items: [
        { text: 'Furosemide 40mg (Diuretic) — listed in discharge sheet', detail: 'Take exactly as written on the sheet', confidence: 0.99 },
        { text: 'Lisinopril 10mg (ACE Inhibitor) — listed in discharge sheet', detail: 'Take exactly as written on the sheet', confidence: 0.95 },
        { text: 'Entry 4 — unreadable handwriting', detail: 'Sent for human review', confidence: 0.38, needsReview: true },
      ],
    },
    {
      id: 'warnings',
      title: 'Warning signs mentioned',
      items: [
        { text: 'Sudden or worsening shortness of breath', detail: 'Report to care team immediately', confidence: 0.98 },
        { text: 'Chest pain or pressure', detail: 'Go to emergency or report to care team', confidence: 0.99 },
        { text: 'Fast weight gain or new swelling in the legs', detail: 'Report to care team', confidence: 0.91 },
        { text: 'Fainting or feeling very dizzy', detail: 'Report to care team', confidence: 0.92 },
      ],
    },
    {
      id: 'instructions',
      title: 'Instructions in simple language',
      items: [
        { text: 'Eat less salt and weigh yourself every morning.', detail: 'From: "Strict sodium restriction; monitor daily weights"', confidence: 0.89 },
        { text: 'Avoid heavy exercise for 2 weeks.', detail: 'From: "Ambulate as tolerated; avoid strenuous exertion x2 weeks"', confidence: 0.94 },
        { text: 'Keep taking your medicines exactly as written.', detail: 'From: "Continue medications per discharge medication reconciliation"', confidence: 0.96 },
        { text: 'Unclear diet advice (two conflicting salt limits found).', detail: 'Sent to care team for clarification', confidence: 0.45, needsReview: true },
      ],
    },
  ],
}
