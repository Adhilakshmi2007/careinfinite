// SERVICE LAYER — the only place pages talk to data.
// Today: returns mock data after a short delay.
// Later: replace the body with fetch('/api/...') or a database call. Pages won't change.
import { mockPatients } from '../data/mockPatients'

const delay = (ms = 250) => new Promise((resolve) => setTimeout(resolve, ms))

export async function getPatients() {
  await delay()
  return structuredClone(mockPatients)
}

export async function getPatientById(id) {
  await delay()
  const patient = mockPatients.find((p) => p.id === id)
  return patient ? structuredClone(patient) : null
}
