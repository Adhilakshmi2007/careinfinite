// SERVICE LAYER for discharge-summary analysis.
// Today: ignores the input and returns sample results after a fake "thinking" delay.
// Later: send the file/text to your backend, which calls an AI model, and return its JSON.
// Keep the returned shape the same as mockExtraction so the UI keeps working.
import { mockExtraction } from '../data/mockExtraction'

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * @param {{ file?: File|null, text?: string }} input
 */
export async function analyzeDischargeSummary(input) {
  void input // not used yet — mock results only
  await delay(1800)
  return structuredClone(mockExtraction)
}
