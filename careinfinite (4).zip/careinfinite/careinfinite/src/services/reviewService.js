// SERVICE LAYER for reviewer cases. Swap mock calls for real API calls later.
import { mockReviewCases } from '../data/mockReviewCases'

const delay = (ms = 250) => new Promise((resolve) => setTimeout(resolve, ms))

export async function getReviewCases() {
  await delay()
  return structuredClone(mockReviewCases)
}

// Later: PATCH /api/review-cases/:id { status }
export async function updateCaseStatus(id, status) {
  await delay(150)
  return { id, status }
}
