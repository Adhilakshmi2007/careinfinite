# CareInfinite — Care that continues beyond discharge

Hackathon prototype. React + Vite + JavaScript + Tailwind CSS.
**All data is synthetic. No real AI, backend, or database yet.**

## Run it

```bash
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173). Needs Node 18+.

## Pages

| Route        | Page                          |
|--------------|-------------------------------|
| `/`          | Landing page                  |
| `/roles`     | Role selection                |
| `/patient`   | Patient dashboard             |
| `/staff`     | Hospital staff dashboard      |
| `/reviewer`  | Reviewer dashboard            |
| `/upload`    | Discharge summary upload      |

## Folder structure

```
careinfinite/
├── index.html
├── package.json
├── vite.config.js · tailwind.config.js · postcss.config.js
├── public/favicon.svg
└── src/
    ├── main.jsx                 # app entry (Router + RoleProvider)
    ├── App.jsx                  # all routes
    ├── index.css                # Tailwind + shared classes (.btn, .card)
    ├── pages/                   # one file per screen
    │   ├── LandingPage.jsx
    │   ├── RoleSelectPage.jsx
    │   ├── PatientDashboard.jsx
    │   ├── StaffDashboard.jsx
    │   ├── ReviewerDashboard.jsx
    │   └── UploadPage.jsx
    ├── components/
    │   ├── layout/              # Navbar, Footer, Layout, PageHeader
    │   ├── ui/                  # Logo, StatusBadge, ProgressBar, StatCard, SafetyNotice, Loading
    │   ├── patient/             # TaskList, Timeline, Reminders, WarningSigns, Instructions
    │   ├── staff/               # PatientTable, AttentionList
    │   ├── reviewer/            # ReviewCaseCard
    │   └── upload/              # FileDropzone, ExtractionResults
    ├── data/                    # MOCK DATA (synthetic) — mockPatients, mockReviewCases, mockExtraction
    ├── services/                # data access layer — pages only call these
    │   ├── patientService.js
    │   ├── reviewService.js
    │   └── dischargeService.js  # analyzeDischargeSummary() — future AI hook
    ├── hooks/useAsync.js        # loads async data for pages
    ├── context/RoleContext.jsx  # selected role (swap for real auth later)
    └── utils/                   # dates.js, tasks.js helpers
```

## How to add the real backend / AI later

Pages never import from `src/data/` directly — only from `src/services/`.
To go live, change the function bodies in `services/` (e.g. `fetch('/api/...')`) and keep the returned shapes.

- **AI extraction:** `services/dischargeService.js` → send file/text to your backend, return the same shape as `data/mockExtraction.js`.
- **Patients/tasks:** `services/patientService.js` (add `updateTask`, currently the dashboard updates local state).
- **Review cases:** `services/reviewService.js` → `updateCaseStatus` is the place to persist.
- **Auth:** replace `context/RoleContext.jsx` with real login.

## Safety rules (keep these in every future change)

CareInfinite must NOT diagnose, prescribe, change medication, recommend treatment, or guarantee provider matches.
It only organises information already in the discharge paperwork. Low-confidence items go to **Needs Review** instead of being guessed.

## Suggested next steps

1. Backend (Node/Express or FastAPI) + database for patients, tasks, cases.
2. Real PDF/DOCX/TXT text extraction, then an LLM call with a strict JSON schema and confidence scores.
3. Route low-confidence extractions automatically into the reviewer queue.
4. Auth with role-based access, audit log of reviewer actions.
