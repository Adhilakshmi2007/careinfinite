const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const { User, StaffUser, ReviewerUser } = require('./models/User');
const PatientUser = require('./models/Patient');
const ReviewCase = require('./models/ReviewCase');

const app = express();
app.use(express.json());
app.use(cors());

// You can change this to your cloud MongoDB URI (e.g., MongoDB Atlas) later
const MONGO_URI = 'mongodb://localhost:27017/careinfinite';

mongoose.connect(MONGO_URI)
  .then(() => console.log('Connected to MongoDB!'))
  .catch(err => console.error('MongoDB connection error:', err));

// Basic Sign Up Route
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { role, name, password, email, hospitalName, staffId, jobRole } = req.body;

    let user;
    if (role === 'patient') {
      user = new PatientUser({ name, password });
    } else if (role === 'staff') {
      user = new StaffUser({ name, password, email, hospitalName, staffId, jobRole });
    } else if (role === 'reviewer') {
      user = new ReviewerUser({ name, password });
    } else {
      return res.status(400).json({ error: 'Invalid role' });
    }

    await user.save();
    res.status(201).json({ message: 'User created successfully', user });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ error: 'User already exists' });
    }
    res.status(500).json({ error: error.message });
  }
});

// Basic Sign In Route
app.post('/api/auth/signin', async (req, res) => {
  try {
    const { identifier, password, role } = req.body;
    
    // Find user by name OR email
    const user = await User.findOne({
      $or: [{ name: identifier }, { email: identifier }],
      role: role
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found. Please sign up first.' });
    }

    if (user.password !== password) {
      return res.status(401).json({ error: 'Incorrect password' });
    }

    res.json({ message: 'Signed in successfully', user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});
