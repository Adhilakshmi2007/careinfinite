const mongoose = require('mongoose');
const { User } = require('./User');

const patientSchema = new mongoose.Schema({
  profile: {
    age: Number,
    gender: String,
    contact: String
  },
  dischargeSummaries: [{
    fileUrl: String,
    uploadedAt: { type: Date, default: Date.now },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }],
  extractedInformation: { type: Map, of: String },
  medications: [{
    name: String,
    dosage: String,
    frequency: String,
    duration: String
  }],
  followUps: [{
    date: Date,
    type: String, // e.g., Clinic Visit, Telehealth
    doctor: String
  }],
  tasks: [{
    description: String,
    completed: { type: Boolean, default: false },
    dueDate: Date
  }],
  checkIns: [{
    date: { type: Date, default: Date.now },
    status: String,
    notes: String
  }]
});

const PatientUser = User.discriminator('patient', patientSchema);

module.exports = PatientUser;
