const mongoose = require('mongoose');

const reviewCaseSchema = new mongoose.Schema({
  patientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  dischargeSummaryId: { type: mongoose.Schema.Types.ObjectId },
  extractedData: { type: Map, of: String },
  confidence: { type: Number },
  reviewer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  status: { type: String, enum: ['pending', 'reviewed', 'resolved'], default: 'pending' },
  corrections: [{
    field: String,
    originalValue: String,
    correctedValue: String,
    correctedAt: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('ReviewCase', reviewCaseSchema);
