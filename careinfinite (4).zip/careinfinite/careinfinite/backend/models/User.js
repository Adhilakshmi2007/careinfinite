const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['patient', 'staff', 'reviewer'], required: true },
}, { discriminatorKey: 'role', collection: 'users' });

const User = mongoose.model('User', userSchema);

const StaffUser = User.discriminator('staff', new mongoose.Schema({
  hospitalName: { type: String, required: true },
  staffId: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  jobRole: { type: String, required: true },
}));

const ReviewerUser = User.discriminator('reviewer', new mongoose.Schema({
  // Add any reviewer-specific fields if needed
}));

module.exports = { User, StaffUser, ReviewerUser };
