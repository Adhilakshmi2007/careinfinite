/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Brand palette — change these to re-theme the whole app
        pine: { 900: '#0B3A40', 800: '#10484F', 700: '#17606A' },
        tide: { 400: '#4DB3BF', 500: '#2A97A5', 600: '#1B7F8C', 700: '#166873' },
        mist: { 50: '#F5F9F8', 100: '#E6F0EE', 200: '#D2E3E0' },
        ink: { DEFAULT: '#14262A', soft: '#43595E', faint: '#6F8387' },
        leaf: { 50: '#E8F5EE', 600: '#2F8F5B', 700: '#23704A' },
        amber: { 50: '#FDF3DF', 500: '#E3A63B', 700: '#8A5A06' },
        clay: { 50: '#FBEAE4', 500: '#C4573A', 700: '#98391F' },
        iris: { 50: '#EEEBFB', 600: '#6B5BD2', 700: '#4F40AE' },
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        sans: ['Figtree', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(11,58,64,0.06), 0 6px 20px -8px rgba(11,58,64,0.12)',
      },
    },
  },
  plugins: [],
}
